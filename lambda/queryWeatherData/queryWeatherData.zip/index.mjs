// ========================================
// queryWeatherData Lambda - With Redis Cache + Signed S3 URLs
// ========================================

import { Client } from 'pg';
import Redis from 'ioredis';
import { S3Client, GetObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';

// --- Redis Client ---
let redisClient = null;

function getRedis() {
  if (!redisClient) {
    redisClient = new Redis({
      host: process.env.REDIS_HOST,
      port: parseInt(process.env.REDIS_PORT) || 6379,
      username: process.env.REDIS_USERNAME || 'default',
      password: process.env.REDIS_PASSWORD,
      retryStrategy: (times) => {
        if (times > 3) {
          console.error('[Redis] Max retries reached');
          return null;
        }
        return Math.min(times * 100, 2000);
      },
      connectTimeout: 10000,
      commandTimeout: 5000
    });

    redisClient.on('error', (err) => {
      console.error('[Redis] Error:', err.message);
    });

    redisClient.on('connect', () => {
      console.log('[Redis] Connected successfully');
    });
  }
  return redisClient;
}

// --- PostgreSQL Config ---
const PG_CONFIG = {
  host: process.env.PG_HOST,
  database: process.env.PG_DB,
  user: process.env.PG_USER,
  password: process.env.PG_PASSWORD,
  port: 5432,
  ssl: { rejectUnauthorized: false }
};

// --- S3 Client ---
const REGION = 'us-east-1';
const s3 = new S3Client({ region: REGION });

const RAW_BUCKET = 'weatherarchive-raw';
const EDITED_BUCKET = 'weatherarchive-edited';
const VIDEO_BUCKET = 'weatherarchive-videos';

// Generate a signed URL for a given bucket/key
async function generateSignedUrl(bucket, key) {
  if (!key) return null;

  const command = new GetObjectCommand({
    Bucket: bucket,
    Key: key
  });

  return await getSignedUrl(s3, command, { expiresIn: 3600 }); // 1 hour
}

/**
 * Get cached data or fetch from database
 */
async function getCachedOrFetch(cacheKey, fetchFn, ttl = 3600) {
  try {
    const redis = getRedis();
    const cached = await redis.get(cacheKey);

    if (cached) {
      console.log(`[Cache] ✓ HIT: ${cacheKey}`);
      return {
        data: JSON.parse(cached),
        source: 'cache'
      };
    }

    console.log(`[Cache] ✗ MISS: ${cacheKey}`);
  } catch (error) {
    console.error(`[Cache] Get error:`, error.message);
  }

  console.log(`[Database] Fetching data...`);
  const data = await fetchFn();

  try {
    const redis = getRedis();
    await redis.setex(cacheKey, ttl, JSON.stringify(data));
    console.log(`[Cache] ✓ Stored: ${cacheKey} (TTL: ${ttl}s)`);
  } catch (error) {
    console.error(`[Cache] Store error:`, error.message);
  }

  return {
    data: data,
    source: 'database'
  };
}

/**
 * Fetch images from PostgreSQL
 */
async function fetchImagesFromDB(citySlug, date, hour) {
  const client = new Client(PG_CONFIG);

  try {
    await client.connect();
    console.log('[Database] Connected to PostgreSQL');

    let query = `
      SELECT 
        id,
        city_slug,
        capture_time,
        camera_id,
        s3_unedited_key,
        s3_edited_key,
        s3_video_key,
        temperature,
        humidity,
        air_pressure,
        processed,
        used_in_video,
        created_at
      FROM images
      WHERE city_slug = $1
    `;

    const params = [citySlug];
    let paramIndex = 2;

    if (date) {
      query += ` AND DATE(capture_time) = $${paramIndex}`;
      params.push(date);
      paramIndex++;
    }

    if (hour !== undefined && hour !== null) {
      query += ` AND EXTRACT(HOUR FROM capture_time) = $${paramIndex}`;
      params.push(parseInt(hour));
      paramIndex++;
    }

    query += ` ORDER BY capture_time DESC LIMIT 100`;

    console.log('[Database] Executing query:', query);
    console.log('[Database] Parameters:', params);

    const result = await client.query(query, params);

    console.log(`[Database] Found ${result.rows.length} images`);

    return result.rows;

  } finally {
    await client.end();
    console.log('[Database] Connection closed');
  }
}

/**
 * Lambda Handler
 */
export const handler = async (event) => {
  console.log('[queryWeatherData] Handler started');
  console.log('[queryWeatherData] Event:', JSON.stringify(event, null, 2));

  // CORS headers for all responses
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,x-api-key,cache-control',
    'Access-Control-Allow-Methods': 'GET,OPTIONS'
  };

  // Handle CORS preflight (OPTIONS) - though this should be handled by API Gateway Mock
  if (event.httpMethod === 'OPTIONS' || event.requestContext?.http?.method === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: ''
    };
  }

  try {
    const pathParams = event.pathParameters || {};
    const queryParams = event.queryStringParameters || {};

    const citySlug = pathParams.city || queryParams.city;
    const date = queryParams.date;
    const hour = queryParams.hour;

    if (!citySlug) {
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json',
          ...corsHeaders
        },
        body: JSON.stringify({
          error: 'Missing required parameter: city',
          usage: 'GET /cities/{city}/images?date=YYYY-MM-DD&hour=0-23'
        })
      };
    }

    let cacheKey = `city:${citySlug}:images`;
    if (date) cacheKey += `:${date}`;
    if (hour !== undefined && hour !== null) cacheKey += `:h${hour}`;

    console.log(`[queryWeatherData] Cache key: ${cacheKey}`);
    console.log(`[queryWeatherData] Query params: city=${citySlug}, date=${date}, hour=${hour}`);

    const result = await getCachedOrFetch(
      cacheKey,
      () => fetchImagesFromDB(citySlug, date, hour),
      3600
    );

    // Enrich rows with signed URLs (do this AFTER cache fetch)
    const imagesWithSignedUrls = await Promise.all(
      result.data.map(async (row) => {
        const enriched = { ...row };

        if (row.s3_unedited_key) {
          enriched.signed_unedited_url = await generateSignedUrl(
            RAW_BUCKET,
            row.s3_unedited_key
          );
        }

        if (row.s3_edited_key) {
          enriched.signed_edited_url = await generateSignedUrl(
            EDITED_BUCKET,
            row.s3_edited_key
          );
        }

        if (row.s3_video_key) {
          enriched.signed_video_url = await generateSignedUrl(
            VIDEO_BUCKET,
            row.s3_video_key
          );
        }

        return enriched;
      })
    );

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        ...corsHeaders
      },
      body: JSON.stringify({
        city: citySlug,
        date: date || 'all',
        hour: hour !== undefined ? parseInt(hour) : 'all',
        count: imagesWithSignedUrls.length,
        source: result.source,
        cached: result.source === 'cache',
        images: imagesWithSignedUrls
      })
    };

  } catch (error) {
    console.error('[queryWeatherData] ERROR:', error);

    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        ...corsHeaders
      },
      body: JSON.stringify({
        error: 'Internal server error',
        message: error.message,
        type: error.name
      })
    };
  }
};
